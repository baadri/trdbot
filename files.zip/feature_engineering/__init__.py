"""
Feature Engineering Module
Handles technical indicators, market microstructure, and feature selection
"""

__version__ = "1.0.0"
__author__ = "baadri"