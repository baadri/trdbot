"""
ML Models Module
Ensemble of neural network models for trading signal generation
"""

__version__ = "1.0.0"
__author__ = "baadri"